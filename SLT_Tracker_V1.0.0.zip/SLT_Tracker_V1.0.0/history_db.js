// MySLT Usage History — monthly snapshots stored locally in IndexedDB.
// Works in both the popup (window) and the background service worker (self).
(function (global) {
  const DB_NAME = 'MySLTHistory';
  const DB_VERSION = 1;
  const STORE = 'monthly';
  const ACK_KEY = 'sltHistoryAck'; // { [accKey]: monthCountWhenAcknowledged }
  const REMINDER_EVERY_MONTHS = 12;

  function reqP(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          const store = db.createObjectStore(STORE, { keyPath: 'id' });
          store.createIndex('acc', 'acc', { unique: false });
          store.createIndex('year', 'year', { unique: false });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  function txDone(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
    });
  }

  function monthKey(date = new Date()) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
  }

  function round3(n) {
    const v = Number(n);
    return Number.isFinite(v) ? Math.round(v * 1000) / 1000 : 0;
  }

  function resolveAccKey(acc, phone) {
    const cleanAcc = String(acc || '').trim();
    if (cleanAcc) return cleanAcc;
    const fmt = global.MySLTUtils?.formatPhoneParams;
    return fmt ? (fmt(phone).telephoneNo || '') : String(phone || '').trim();
  }

  function toStoredPackages(packages) {
    const seen = {};
    return (packages || []).map(pkg => {
      const base = `${pkg.name || 'Package'}|${pkg.subLabel || ''}`;
      seen[base] = (seen[base] || 0) + 1;
      const key = seen[base] > 1 ? `${base}|${seen[base]}` : base;
      return {
        key,
        name: pkg.name || 'Package',
        subLabel: pkg.subLabel || '',
        usedGB: round3(pkg.usedGB),
        limitGB: round3(pkg.limitGB),
        remainingGB: round3(pkg.remainingGB),
        isUnlimited: !!pkg.isUnlimited
      };
    });
  }

  // Usage counters are cumulative within a month, so the highest value seen
  // per package is that month's usage. Packages seen earlier in the month
  // (e.g. expired Extra GB) are kept.
  function mergePackages(oldPkgs, newPkgs) {
    const map = new Map();
    (oldPkgs || []).forEach(p => map.set(p.key, p));
    (newPkgs || []).forEach(p => {
      const prev = map.get(p.key);
      if (!prev || p.usedGB >= prev.usedGB) map.set(p.key, p);
    });
    return Array.from(map.values());
  }

  function computeTotals(pkgs) {
    let totalUsedGB = 0;
    let totalLimitGB = 0;
    let hasUnlimited = false;
    pkgs.forEach(p => {
      totalUsedGB += p.usedGB || 0;
      if (p.isUnlimited) hasUnlimited = true;
      else totalLimitGB += p.limitGB || 0;
    });
    return { totalUsedGB: round3(totalUsedGB), totalLimitGB: round3(totalLimitGB), hasUnlimited };
  }

  async function saveMonthlySnapshot({ acc, phone, packages, packageName, now = new Date() }) {
    const accKey = resolveAccKey(acc, phone);
    const newPkgs = toStoredPackages(packages);
    if (!accKey || newPkgs.length === 0) return null;

    const month = monthKey(now);
    const id = `${accKey}|${month}`;
    const db = await openDb();
    try {
      const tx = db.transaction(STORE, 'readwrite');
      const store = tx.objectStore(STORE);
      const done = txDone(tx);
      const existing = await reqP(store.get(id));
      const merged = mergePackages(existing?.packages, newPkgs);
      const record = {
        id,
        acc: accKey,
        month,
        year: now.getFullYear(),
        packageName: packageName || existing?.packageName || '',
        firstSeen: existing?.firstSeen || now.toISOString(),
        updatedAt: now.toISOString(),
        packages: merged,
        ...computeTotals(merged)
      };
      store.put(record);
      await done;
      return record;
    } finally {
      db.close();
    }
  }

  // Convenience: save straight from fetchAllMySLTData() results.
  async function saveFromFetchResults({ usageRes, extraRes, vasRes, acc, phone }) {
    const utils = global.MySLTUtils;
    if (!utils) return null;
    const packages = utils.collectPackages(usageRes, extraRes, vasRes);
    if (!packages.length) return null;
    const bundle = usageRes?.ok ? usageRes.data?.dataBundle : null;
    return saveMonthlySnapshot({
      acc,
      phone,
      packages,
      packageName: bundle?.my_package_info?.package_name || ''
    });
  }

  async function getAllRecords(accKey) {
    const db = await openDb();
    try {
      const tx = db.transaction(STORE, 'readonly');
      const store = tx.objectStore(STORE);
      const rows = accKey
        ? await reqP(store.index('acc').getAll(accKey))
        : await reqP(store.getAll());
      return rows.sort((a, b) => (a.month < b.month ? 1 : a.month > b.month ? -1 : 0));
    } finally {
      db.close();
    }
  }

  async function clearRecords(accKey, year) {
    const rows = await getAllRecords(accKey);
    const targets = rows.filter(r => !year || r.year === Number(year));
    if (!targets.length) return 0;
    const db = await openDb();
    try {
      const tx = db.transaction(STORE, 'readwrite');
      const store = tx.objectStore(STORE);
      const done = txDone(tx);
      targets.forEach(r => store.delete(r.id));
      await done;
      return targets.length;
    } finally {
      db.close();
    }
  }

  // ----- 12-month export/clear reminder -----
  async function getAckMap() {
    try {
      const data = await chrome.storage.local.get([ACK_KEY]);
      return data?.[ACK_KEY] || {};
    } catch {
      return {};
    }
  }

  async function acknowledge(accKey, monthCount) {
    const map = await getAckMap();
    map[accKey || '_all'] = monthCount;
    await chrome.storage.local.set({ [ACK_KEY]: map });
  }

  async function needsReminder(accKey, monthCount) {
    const map = await getAckMap();
    const acked = Number(map[accKey || '_all'] || 0);
    // If history was cleared, the count can drop below the old ack value
    const base = monthCount < acked ? 0 : acked;
    return monthCount - base >= REMINDER_EVERY_MONTHS;
  }

  // ----- Export helpers -----
  function toCsv(rows) {
    const esc = v => {
      const s = String(v ?? '');
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const header = ['Month', 'Account', 'Main Package', 'Package', 'Type', 'Used (GB)', 'Limit (GB)', 'Remaining (GB)', 'Unlimited', 'Last Updated'];
    const lines = [header.join(',')];
    rows.slice().reverse().forEach(r => {
      r.packages.forEach(p => {
        lines.push([
          r.month, r.acc, r.packageName, p.name, p.subLabel,
          p.usedGB, p.isUnlimited ? '' : p.limitGB, p.isUnlimited ? '' : p.remainingGB,
          p.isUnlimited ? 'Yes' : 'No', r.updatedAt
        ].map(esc).join(','));
      });
    });
    return lines.join('\r\n');
  }

  function toJson(rows) {
    return JSON.stringify({
      app: 'MySLT Tracker',
      exportedAt: new Date().toISOString(),
      records: rows.slice().reverse()
    }, null, 2);
  }

  global.MySLTHistory = {
    REMINDER_EVERY_MONTHS,
    monthKey,
    resolveAccKey,
    saveMonthlySnapshot,
    saveFromFetchResults,
    getAllRecords,
    clearRecords,
    acknowledge,
    needsReminder,
    toCsv,
    toJson
  };
})(typeof self !== 'undefined' ? self : window);
