const {
  normalizeToken,
  formatPhoneParams,
  escapeHtml,
  fetchAllMySLTData,
  extractBillInfo,
  formatGb,
  collectPackages,
  calculateTotals
} = window.MySLTUtils;

let currentPayableAmount = 0;

const MYSLT_URL = 'https://myslt.slt.lk/';

// ---------------- Usage History (IndexedDB) ----------------
const UsageHistory = window.MySLTHistory;
let refreshHistoryDot = async () => {};

function formatMonthLabel(month) {
  const [y, m] = String(month).split('-').map(Number);
  if (!y || !m) return month;
  return new Date(y, m - 1, 1).toLocaleString('en-US', { month: 'long', year: 'numeric' });
}

function downloadText(filename, text, mime) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function initHistory() {
  const historyBtn = document.getElementById('historyBtn');
  const historyDot = document.getElementById('historyDot');
  const modal = document.getElementById('historyModal');
  const closeBtn = document.getElementById('closeHistoryBtn');
  const yearFilter = document.getElementById('historyYearFilter');
  const listEl = document.getElementById('historyList');
  const summaryEl = document.getElementById('historySummary');
  const exportCsvBtn = document.getElementById('historyExportCsvBtn');
  const exportJsonBtn = document.getElementById('historyExportJsonBtn');
  const clearBtn = document.getElementById('historyClearBtn');
  const reminder = document.getElementById('historyReminder');
  const reminderCount = document.getElementById('historyReminderCount');
  const reminderExportBtn = document.getElementById('reminderExportBtn');
  const reminderClearBtn = document.getElementById('reminderClearBtn');
  const reminderKeepBtn = document.getElementById('reminderKeepBtn');

  if (!UsageHistory || !historyBtn || !modal) return;

  let accKey = '';
  let allRows = [];

  async function loadAccKey() {
    const data = await chrome.storage.local.get(['sltAcc', 'sltPhone']).catch(() => ({}));
    accKey = UsageHistory.resolveAccKey(data?.sltAcc, data?.sltPhone);
  }

  async function loadRows() {
    await loadAccKey();
    allRows = await UsageHistory.getAllRecords(accKey || undefined).catch(() => []);
  }

  function filteredRows() {
    const y = yearFilter.value;
    return y === 'all' ? allRows : allRows.filter(r => String(r.year) === y);
  }

  function fillYearFilter() {
    const prev = yearFilter.value;
    const years = [...new Set(allRows.map(r => r.year))].sort((a, b) => b - a);
    yearFilter.innerHTML = `<option value="all">All years</option>` +
      years.map(y => `<option value="${y}">${y}</option>`).join('');
    if (prev && [...yearFilter.options].some(o => o.value === prev)) {
      yearFilter.value = prev;
    } else {
      yearFilter.value = years.includes(new Date().getFullYear()) ? String(new Date().getFullYear()) : 'all';
    }
  }

  function renderList() {
    const rows = filteredRows();
    if (!rows.length) {
      summaryEl.textContent = '';
      listEl.innerHTML = `<div class="history-empty">No history saved yet. Usage is saved automatically each month.</div>`;
      return;
    }

    const totalUsed = rows.reduce((sum, r) => sum + (r.totalUsedGB || 0), 0);
    const avg = totalUsed / rows.length;
    const label = yearFilter.value === 'all' ? 'All years' : yearFilter.value;
    summaryEl.textContent = `${label}: ${rows.length} month${rows.length > 1 ? 's' : ''} • Total ${formatGb(totalUsed)} • Avg ${formatGb(avg)}/month`;

    listEl.innerHTML = rows.map(r => {
      const updated = new Date(r.updatedAt);
      const updatedStr = Number.isNaN(updated.getTime()) ? '' : updated.toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' });
      const pkgs = (r.packages || []).map(p => {
        const val = p.isUnlimited
          ? `${formatGb(p.usedGB)} / Unl.`
          : `${formatGb(p.usedGB)} / ${formatGb(p.limitGB)}`;
        return `
          <div class="history-pkg">
            <span class="history-pkg-name" title="${escapeHtml(p.name)}">${escapeHtml(p.name)}${p.subLabel ? `<span class="history-pkg-sub">${escapeHtml(p.subLabel)}</span>` : ''}</span>
            <span class="history-pkg-val">${escapeHtml(val)}</span>
          </div>`;
      }).join('');
      return `
        <div class="history-month">
          <div class="history-month-head">
            <span class="history-month-name">${escapeHtml(formatMonthLabel(r.month))}</span>
            <span class="history-month-total">${escapeHtml(formatGb(r.totalUsedGB))} used</span>
          </div>
          <div class="history-month-meta">${escapeHtml(r.packageName || '')}${r.packageName && updatedStr ? ' • ' : ''}${updatedStr ? `Last saved ${escapeHtml(updatedStr)}` : ''}</div>
          ${pkgs}
        </div>`;
    }).join('');
  }

  async function updateReminder() {
    const count = allRows.length;
    const show = count > 0 && await UsageHistory.needsReminder(accKey, count);
    reminder.style.display = show ? 'block' : 'none';
    reminderCount.textContent = String(count);
    historyDot.style.display = show ? 'block' : 'none';
  }

  async function refreshAll() {
    await loadRows();
    fillYearFilter();
    renderList();
    await updateReminder();
  }

  refreshHistoryDot = async () => {
    await loadRows();
    await updateReminder();
  };

  function exportRows(rows, type) {
    if (!rows.length) return false;
    const suffix = yearFilter.value === 'all' || rows === allRows ? 'all' : yearFilter.value;
    const base = `myslt_usage_${accKey || 'history'}_${suffix}`;
    if (type === 'json') downloadText(`${base}.json`, UsageHistory.toJson(rows), 'application/json');
    else downloadText(`${base}.csv`, UsageHistory.toCsv(rows), 'text/csv');
    return true;
  }

  // Two-click confirm (window.confirm can close the extension popup)
  function armConfirm(btn, idleText, action) {
    let armed = false;
    let timer = null;
    btn.addEventListener('click', async () => {
      if (!armed) {
        armed = true;
        btn.textContent = 'Confirm?';
        timer = setTimeout(() => { armed = false; btn.textContent = idleText; }, 3000);
        return;
      }
      clearTimeout(timer);
      armed = false;
      btn.textContent = idleText;
      await action();
    });
  }

  historyBtn.addEventListener('click', async () => {
    modal.style.display = 'flex';
    listEl.innerHTML = `<div class="history-empty">Loading...</div>`;
    await refreshAll();
  });
  closeBtn?.addEventListener('click', () => { modal.style.display = 'none'; });
  modal.addEventListener('click', (e) => { if (e.target === modal) modal.style.display = 'none'; });
  yearFilter.addEventListener('change', renderList);

  exportCsvBtn.addEventListener('click', () => exportRows(filteredRows(), 'csv'));
  exportJsonBtn.addEventListener('click', () => exportRows(filteredRows(), 'json'));

  armConfirm(clearBtn, 'Clear', async () => {
    const y = yearFilter.value;
    await UsageHistory.clearRecords(accKey || undefined, y === 'all' ? undefined : Number(y));
    await refreshAll();
  });

  reminderExportBtn.addEventListener('click', async () => {
    if (exportRows(allRows, 'csv')) {
      await UsageHistory.acknowledge(accKey, allRows.length);
      await updateReminder();
    }
  });

  armConfirm(reminderClearBtn, 'Clear All', async () => {
    await UsageHistory.clearRecords(accKey || undefined);
    await UsageHistory.acknowledge(accKey, 0);
    await refreshAll();
  });

  reminderKeepBtn.addEventListener('click', async () => {
    await UsageHistory.acknowledge(accKey, allRows.length);
    await updateReminder();
  });

  refreshHistoryDot().catch(() => {});
}

async function saveHistorySnapshot(acc, phone, packages, packageName) {
  if (!UsageHistory) return;
  try {
    await UsageHistory.saveMonthlySnapshot({ acc, phone, packages, packageName });
    await refreshHistoryDot();
  } catch {
    // Ignore IndexedDB failures; usage display should still work
  }
}

function appendOpenMySLTButton(container) {
  if (!container) return;
  container.classList.remove('cols-1', 'cols-2', 'cols-3');
  container.insertAdjacentHTML(
    'beforeend',
    `<a class="open-myslt-btn" href="${MYSLT_URL}" target="_blank" rel="noreferrer">Open MySLT</a>`
  );
}

function formatPayAmount(num) {
  // Send whole numbers as-is (e.g. "100"), otherwise 2 decimals (e.g. "1234.50")
  return Number.isInteger(num) ? String(num) : num.toFixed(2);
}

function initPayModal() {
  const payNowBtn = document.getElementById('payNowBtn');
  const payModal = document.getElementById('payModal');
  const closePayBtn = document.getElementById('closePayBtn');
  const payBillOption = document.getElementById('payBillOption');
  const payBillCheck = document.getElementById('payBillCheck');
  const payBillAmountLabel = document.getElementById('payBillAmountLabel');
  const payCustomBox = document.getElementById('payCustomBox');
  const payCustomInput = document.getElementById('payCustomInput');
  const payError = document.getElementById('payError');
  const payForm = document.getElementById('payForm');
  const payEventSource = document.getElementById('payEventSource');
  const payVpcAmount = document.getElementById('payVpcAmount');
  const payTelLabel = document.getElementById('payTelLabel');

  if (!payNowBtn || !payModal || !payForm) return;

  function showError(msg) {
    payError.textContent = msg;
    payError.style.display = msg ? 'block' : 'none';
  }

  function syncCustomVisibility() {
    const useBill = payBillCheck.checked;
    payCustomBox.style.display = useBill ? 'none' : 'block';
    if (!useBill) payCustomInput.focus();
    showError('');
  }

  function hidePayModal() {
    payModal.style.display = 'none';
  }

  payNowBtn.addEventListener('click', async () => {
    const data = await chrome.storage.local.get(['sltPhone']).catch(() => ({}));
    const { telephoneNo } = formatPhoneParams(data?.sltPhone);
    payEventSource.value = telephoneNo || '';
    payTelLabel.textContent = telephoneNo ? `Telephone: ${telephoneNo}` : 'Telephone number not set';

    const hasBill = currentPayableAmount > 0;
    payBillAmountLabel.textContent = `Rs. ${currentPayableAmount.toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    // If there is no payable bill amount, hide the checkbox and go straight to custom input
    payBillOption.style.display = hasBill ? 'flex' : 'none';
    payBillCheck.checked = hasBill;
    payCustomInput.value = '';
    payModal.style.display = 'flex';
    syncCustomVisibility();
  });

  payBillCheck.addEventListener('change', syncCustomVisibility);
  payCustomInput.addEventListener('input', () => showError(''));
  closePayBtn?.addEventListener('click', hidePayModal);
  payModal.addEventListener('click', (e) => {
    if (e.target === payModal) hidePayModal();
  });

  payForm.addEventListener('submit', (e) => {
    if (!payEventSource.value) {
      e.preventDefault();
      showError('Please set your telephone number in Settings first.');
      return;
    }

    const amount = payBillCheck.checked
      ? currentPayableAmount
      : Number(String(payCustomInput.value).replace(/,/g, ''));

    if (!Number.isFinite(amount) || amount <= 0) {
      e.preventDefault();
      showError('Please enter a valid amount.');
      return;
    }

    payVpcAmount.value = formatPayAmount(Math.round(amount * 100) / 100);
    setTimeout(hidePayModal, 100);
  });
}

function populateSetupInputs(data) {
  const tokenInput = document.getElementById('tokenInput');
  const phoneInput = document.getElementById('phoneInput');
  const accInput = document.getElementById('accInput');
  if (tokenInput) tokenInput.value = data?.sltToken || '';
  if (phoneInput) phoneInput.value = data?.sltPhone || '';
  if (accInput) accInput.value = data?.sltAcc || '';
}

function updateAccountBadge(acc, phone) {
  const badge = document.getElementById('accountBadge');
  if (!badge) return;
  const cleanAcc = String(acc || '').trim();
  const { telephoneNo } = formatPhoneParams(phone);
  if (cleanAcc) {
    badge.textContent = telephoneNo ? `Acc: ${cleanAcc} • ${telephoneNo}` : `Acc: ${cleanAcc}`;
    badge.style.display = 'inline-block';
  } else {
    badge.style.display = 'none';
  }
}

function renderBillInfo(billRes, billEl, billMetaEl) {
  const { displayAmount, metaParts, payableAmount } = extractBillInfo(billRes);
  billEl.textContent = displayAmount;
  currentPayableAmount = billRes?.ok ? (payableAmount || 0) : 0;
  const payNowBtn = document.getElementById('payNowBtn');
  if (payNowBtn) payNowBtn.style.display = 'block';

  if (!billMetaEl) return;
  if (metaParts.length > 0) {
    billMetaEl.innerHTML = metaParts.map(part => `<span>${escapeHtml(part)}</span>`).join('');
    billMetaEl.style.display = 'flex';
  } else {
    billMetaEl.style.display = 'none';
  }
}

async function initPopup() {
  const setupBox = document.getElementById('setupBox');
  const totalBillEl = document.getElementById('totalBill');
  const usageContainer = document.getElementById('usageContainer');
  const refreshBtn = document.getElementById('refreshBtn');
  const saveBtn = document.getElementById('saveBtn');
  const resetBtn = document.getElementById('resetBtn');
  const settingsBtn = document.getElementById('settingsBtn');
  const fullscreenBtn = document.getElementById('fullscreenBtn');
  const billMetaEl = document.getElementById('billMeta');
  const summaryCard = document.getElementById('summaryCard');
  const dashboardTop = document.getElementById('dashboardTop');
  const noticeModal = document.getElementById('noticeModal');
  const openNoticeBtn = document.getElementById('openNoticeBtn');
  const closeNoticeBtn = document.getElementById('closeNoticeBtn');
  const dismissNoticeBtn = document.getElementById('dismissNoticeBtn');
  const whatsappFeedbackBtn = document.getElementById('whatsappFeedbackBtn');

  initPayModal();
  initHistory();

  function showNoticeModal() {
    if (noticeModal) noticeModal.style.display = 'flex';
  }

  function hideNoticeModal(persistDismiss = true) {
    if (noticeModal) noticeModal.style.display = 'none';
    if (persistDismiss) {
      chrome.storage.local.set({ sltNoticeDismissed: true }).catch(() => {});
    }
  }

  if (openNoticeBtn) {
    openNoticeBtn.addEventListener('click', showNoticeModal);
  }
  if (closeNoticeBtn) {
    closeNoticeBtn.addEventListener('click', () => hideNoticeModal(true));
  }
  if (dismissNoticeBtn) {
    dismissNoticeBtn.addEventListener('click', () => hideNoticeModal(true));
  }
  if (whatsappFeedbackBtn) {
    whatsappFeedbackBtn.addEventListener('click', () => hideNoticeModal(true));
  }
  if (noticeModal) {
    noticeModal.addEventListener('click', (e) => {
      if (e.target === noticeModal) hideNoticeModal(true);
    });
  }

  if (!setupBox || !totalBillEl || !usageContainer || !refreshBtn || !saveBtn) {
    console.error('Missing required elements in popup.html.');
    return;
  }

  const isFullscreenPage = new URLSearchParams(window.location.search).get('fullscreen') === '1';
  if (isFullscreenPage) {
    document.body.classList.add('fullscreen-mode');
    if (fullscreenBtn) {
      fullscreenBtn.title = 'Toggle Browser Fullscreen';
    }
  }

  if (fullscreenBtn) {
    fullscreenBtn.addEventListener('click', async () => {
      if (!isFullscreenPage) {
        await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?fullscreen=1') });
        return;
      }
      try {
        if (document.fullscreenElement) {
          await document.exitFullscreen();
        } else if (document.documentElement.requestFullscreen) {
          await document.documentElement.requestFullscreen();
        }
      } catch {
        // Ignore fullscreen API rejection if blocked by user gesture policy
      }
    });
  }

  if (settingsBtn) {
    settingsBtn.addEventListener('click', async () => {
      const isHidden = setupBox.style.display === 'none' || setupBox.style.display === '';
      if (isHidden) {
        try {
          const data = await chrome.storage.local.get(['sltToken', 'sltPhone', 'sltAcc']);
          populateSetupInputs(data);
        } catch {
          // Ignore storage read failure when opening setup form manually
        }
        setupBox.style.display = 'block';
      } else {
        setupBox.style.display = 'none';
      }
    });
  }

  refreshBtn.addEventListener('click', async () => {
    const freshData = await chrome.storage.local.get(['sltToken', 'sltPhone', 'sltAcc']);
    if (freshData.sltToken && freshData.sltPhone && freshData.sltAcc) {
      fetchMySLTData(freshData.sltToken, freshData.sltPhone, freshData.sltAcc);
    } else {
      setupBox.style.display = 'block';
      totalBillEl.textContent = "Setup Required";
    }
  });

  saveBtn.addEventListener('click', async () => {
    const token = normalizeToken(document.getElementById('tokenInput')?.value);
    const phone = document.getElementById('phoneInput')?.value.trim() || '';
    const acc = document.getElementById('accInput')?.value.trim() || '';
    if (token && phone && acc) {
      await chrome.storage.local.set({ sltToken: token, sltPhone: phone, sltAcc: acc });
      setupBox.style.display = 'none';
      fetchMySLTData(token, phone, acc);
    }
  });

  if (resetBtn) {
    resetBtn.addEventListener('click', async () => {
      await chrome.storage.local.remove(['sltToken', 'sltPhone', 'sltAcc']);
      populateSetupInputs({});
      updateAccountBadge('', '');
      setupBox.style.display = 'block';
      totalBillEl.textContent = "Setup Required";
      if (billMetaEl) billMetaEl.style.display = 'none';
      currentPayableAmount = 0;
      const payNowBtnEl = document.getElementById('payNowBtn');
      if (payNowBtnEl) payNowBtnEl.style.display = 'none';
      if (summaryCard) summaryCard.style.display = 'none';
      if (dashboardTop) dashboardTop.classList.remove('has-summary');
      usageContainer.classList.remove('cols-1', 'cols-2', 'cols-3');
      usageContainer.innerHTML = `<p class="status-msg">Settings reset. Open <a href="https://myslt.slt.lk/" target="_blank" rel="noreferrer">myslt.slt.lk</a> to test auto-detect, or enter credentials above.</p>`;
    });
  }

  chrome.storage.onChanged.addListener(async (changes, areaName) => {
    if (areaName !== 'local') return;
    if (!changes.sltToken && !changes.sltPhone && !changes.sltAcc) return;

    try {
      const latest = await chrome.storage.local.get(['sltToken', 'sltPhone', 'sltAcc']);
      const activeId = document.activeElement?.id;
      const isEditingSetup = activeId === 'tokenInput' || activeId === 'phoneInput' || activeId === 'accInput';
      if (!isEditingSetup) {
        populateSetupInputs(latest);
      }

      if (latest.sltToken && latest.sltPhone && latest.sltAcc) {
        if (setupBox.style.display !== 'none' || totalBillEl.textContent === 'Setup Required') {
          setupBox.style.display = 'none';
          fetchMySLTData(latest.sltToken, latest.sltPhone, latest.sltAcc);
        }
      } else {
        updateAccountBadge(latest.sltAcc || '', latest.sltPhone || '');
      }
    } catch {
      // Ignore transient storage read failures
    }
  });

  try {
    const data = await chrome.storage.local.get(['sltToken', 'sltPhone', 'sltAcc', 'sltNoticeDismissed']);

    if (!data.sltNoticeDismissed) {
      showNoticeModal();
    }

    if (!data.sltToken || !data.sltPhone || !data.sltAcc) {
      populateSetupInputs(data);
      setupBox.style.display = 'block';
      totalBillEl.textContent = "Setup Required";
      usageContainer.innerHTML = `<p class="status-msg">Open <a href="https://myslt.slt.lk/" target="_blank" rel="noreferrer">https://myslt.slt.lk/</a> and sign in to auto-detect your account, or enter your credentials above.</p>`;
    } else {
      fetchMySLTData(data.sltToken, data.sltPhone, data.sltAcc);
    }
  } catch (err) {
    totalBillEl.textContent = "Error";
    usageContainer.innerHTML = `<p class="status-msg">Error: ${escapeHtml(err.message)}</p>`;
    appendOpenMySLTButton(usageContainer);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPopup);
} else {
  initPopup();
}

async function fetchMySLTData(token, phone, acc) {
  const container = document.getElementById('usageContainer');
  const billEl = document.getElementById('totalBill');
  const billMetaEl = document.getElementById('billMeta');
  const setupBox = document.getElementById('setupBox');
  const summaryCard = document.getElementById('summaryCard');
  const dashboardTop = document.getElementById('dashboardTop');

  function setSummaryHidden() {
    if (summaryCard) summaryCard.style.display = 'none';
    if (dashboardTop) dashboardTop.classList.remove('has-summary');
    container.classList.remove('cols-1', 'cols-2', 'cols-3');
  }

  if (!container || !billEl) {
    console.error('Missing usageContainer or totalBill element in popup.html.');
    return;
  }

  const cleanToken = normalizeToken(token);
  const { subscriberID } = formatPhoneParams(phone);
  const cleanAcc = String(acc || '').trim();

  updateAccountBadge(cleanAcc, phone);
  billEl.textContent = "Fetching...";
  if (billMetaEl) billMetaEl.style.display = 'none';
  setSummaryHidden();
  container.innerHTML = `<p class="status-msg">Connecting to MySLT server...</p>`;

  try {
    const { usageRes, extraRes, vasRes, billRes } = await fetchAllMySLTData(cleanToken, phone, cleanAcc);

    renderBillInfo(billRes, billEl, billMetaEl);

    const allPackages = collectPackages(usageRes, extraRes, vasRes);

    if (allPackages.length === 0) {
      setSummaryHidden();
      const apiErrMsg = usageRes.data?.errorMessage || usageRes.data?.errorMessege || usageRes.data?.errorShow || usageRes.data?.message;
      const portalLink = `<a href="https://myslt.slt.lk/" target="_blank" rel="noreferrer">https://myslt.slt.lk/</a>`;
      if (usageRes.status === 401 || usageRes.status === 403) {
        billEl.textContent = "Auth Error";
        if (setupBox) {
          populateSetupInputs({ sltToken: cleanToken, sltPhone: phone, sltAcc: cleanAcc });
          setupBox.style.display = 'block';
        }
        container.innerHTML = `<p class="status-msg">Token expired or invalid (HTTP ${usageRes.status}). Open ${portalLink} and log in if you are logged out, or enter a new token above.</p>`;
      } else if (!usageRes.ok) {
        const msg = usageRes.error || apiErrMsg || 'Unable to fetch usage data';
        container.innerHTML = `<p class="status-msg">API Error (${escapeHtml(usageRes.status || 'Network')}): ${escapeHtml(msg)}. Open ${portalLink} and log in if logged out, or try again.</p>`;
      } else if (usageRes.data?.isSuccess === false || apiErrMsg) {
        container.innerHTML = `<p class="status-msg">${escapeHtml(apiErrMsg || 'API returned no data')}. Open ${portalLink} and log in if logged out.</p>`;
      } else {
        container.innerHTML = `<p class="status-msg">No usage data found (${escapeHtml(subscriberID)}). Your token may have expired — open ${portalLink} and log in if logged out.</p>`;
      }
      appendOpenMySLTButton(container);
      return;
    }

    if (summaryCard) {
      const totals = calculateTotals(allPackages);
      const bundle = usageRes.ok ? usageRes.data?.dataBundle : null;
      const pkgName = bundle?.my_package_info?.package_name || 'MySLT Usage';
      saveHistorySnapshot(cleanAcc, phone, allPackages, bundle?.my_package_info?.package_name || '');
      const status = bundle?.status ? ` • ${bundle.status}` : '';
      const reportedTime = bundle?.reported_time || bundle?.my_package_info?.reported_time || '';
      const limitLabel = totals.hasUnlimited
        ? (totals.totalLimitGB > 0 ? `${formatGb(totals.totalLimitGB)} + Unl.` : 'Unlimited')
        : formatGb(totals.totalLimitGB);

      summaryCard.innerHTML = `
        <div class="summary-top">
          <span class="summary-pkg">${escapeHtml(`${pkgName}${status}`)}</span>
          ${reportedTime ? `<span class="summary-meta">${escapeHtml(reportedTime)}</span>` : ''}
        </div>
        <div class="summary-grid">
          <div class="summary-stat">
            <span class="summary-stat-label">Total Used</span>
            <span class="summary-stat-value">${escapeHtml(formatGb(totals.totalUsedGB))}</span>
          </div>
          <div class="summary-stat">
            <span class="summary-stat-label">Remaining</span>
            <span class="summary-stat-value">${escapeHtml(formatGb(totals.totalRemainingGB))}</span>
            ${totals.remainingSourceText ? `<span class="summary-stat-sub" title="${escapeHtml(totals.remainingSourceText)}">${escapeHtml(totals.remainingSourceText)}</span>` : ''}
          </div>
          <div class="summary-stat">
            <span class="summary-stat-label">Total Limit</span>
            <span class="summary-stat-value">${escapeHtml(limitLabel)}</span>
          </div>
        </div>
      `;
      summaryCard.style.display = '';
      if (dashboardTop) dashboardTop.classList.add('has-summary');
    }

    container.classList.remove('cols-1', 'cols-2', 'cols-3');
    if (allPackages.length === 1) container.classList.add('cols-1');
    else if (allPackages.length === 2 || allPackages.length === 4) container.classList.add('cols-2');
    else container.classList.add('cols-3');

    container.innerHTML = '';
    allPackages.forEach(pkg => {
      const isExhausted = !pkg.isUnlimited && pkg.remainingGB <= 0;
      const rightFooter = pkg.isUnlimited
        ? 'Unlimited'
        : `${escapeHtml(formatGb(pkg.remainingGB))} Left (${pkg.percent}%)`;

      const card = document.createElement('div');
      card.className = 'usage-card';
      card.innerHTML = `
        <div class="usage-header">
          <div class="pkg-title-group">
            <span class="pkg-name">${escapeHtml(pkg.name)}</span>
            ${pkg.subLabel ? `<span class="pkg-sub">${escapeHtml(pkg.subLabel)}</span>` : ''}
          </div>
          ${pkg.validTill ? `<span class="valid-till">${escapeHtml(pkg.validTill)}</span>` : ''}
        </div>
        <div class="usage-bottom">
          <div class="progress-bg ${isExhausted ? 'exhausted' : ''}">
            <div class="progress-fill ${pkg.isLow ? 'low' : ''}" style="width: ${pkg.isUnlimited ? 100 : pkg.percent}%;"></div>
          </div>
          <div class="usage-footer">
            <span>${escapeHtml(pkg.usedText)}</span>
            <span class="${isExhausted ? 'exhausted-text' : ''}">${rightFooter}</span>
          </div>
        </div>
      `;
      container.appendChild(card);
    });

  } catch (err) {
    billEl.textContent = "Error";
    if (billMetaEl) billMetaEl.style.display = 'none';
    setSummaryHidden();
    container.innerHTML = `<p class="status-msg">Error: ${escapeHtml(err.message)}</p>`;
    appendOpenMySLTButton(container);
  }
}
