importScripts('slt_utils.js', 'history_db.js');

const AUTO_SAVE_ALARM = 'mysltAutoSave';
const AUTO_SAVE_PERIOD_MIN = 360; // every 6 hours

async function ensureAutoSaveAlarm() {
  try {
    const existing = await chrome.alarms.get(AUTO_SAVE_ALARM);
    if (!existing) {
      await chrome.alarms.create(AUTO_SAVE_ALARM, { delayInMinutes: 1, periodInMinutes: AUTO_SAVE_PERIOD_MIN });
    }
  } catch {
    // Ignore alarm API failures
  }
}

async function autoSaveUsageHistory() {
  try {
    const stored = await chrome.storage.local.get(['sltToken', 'sltPhone', 'sltAcc']);
    if (!stored.sltToken || !stored.sltPhone) return;
    const res = await MySLTUtils.fetchAllMySLTData(stored.sltToken, stored.sltPhone, stored.sltAcc || '');
    await MySLTHistory.saveFromFetchResults({
      ...res,
      acc: res.cleanAcc || stored.sltAcc || '',
      phone: stored.sltPhone
    });
  } catch {
    // Network/token errors: try again on the next alarm
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm?.name === AUTO_SAVE_ALARM) autoSaveUsageHistory();
});

async function injectIntoOpenMySLTTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: "https://myslt.slt.lk/*" });
    for (const tab of tabs) {
      if (!tab.id) continue;
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['page_hook.js'],
          world: 'MAIN'
        });
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['slt_utils.js', 'content.js']
        });
      } catch {
        // Ignore tabs that cannot be scripted
      }
    }
  } catch {
    // Ignore tab query errors
  }
}

chrome.runtime.onInstalled.addListener(() => {
  injectIntoOpenMySLTTabs();
  ensureAutoSaveAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  injectIntoOpenMySLTTabs();
  ensureAutoSaveAlarm();
  autoSaveUsageHistory();
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request?.action === "fetchMySLTData") {
    handleFetchMySLTData(request)
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (request?.action === "openDashboard") {
    chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?fullscreen=1') })
      .then(() => sendResponse({ success: true }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});
async function handleFetchMySLTData(request) {
  const stored = await chrome.storage.local.get(['sltToken', 'sltPhone', 'sltAcc']);
  const token = request.token || stored.sltToken;
  const phone = request.phone || stored.sltPhone;
  const acc = request.acc ?? stored.sltAcc ?? '';

  if (!token || !phone) {
    throw new Error("Missing token or subscriber phone.");
  }

  return MySLTUtils.fetchAllMySLTData(token, phone, acc);
}
